import React, { useState } from "react";
import { motion } from "framer-motion";
import { Lock, Mail } from "lucide-react";
import Reveal from "../components/Reveal.jsx";

export default function AdminLogin() {
  const [form, setForm] = useState({ email: "admin@gmail.com", password: "admin" });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = (e) => {
    e.preventDefault();
    setError("");
    if (!form.email || !form.password) {
      setError("Please enter both email and password.");
      return;
    }
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      // For now just simulate success
      window.alert("Admin login simulated — replace with real auth.");
    }, 900);
  };

  return (
    <div>
      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-4xl px-5 md:px-8">
          <Reveal>
            <span className="eyebrow">Admin</span>
            <h1 className="mt-3 font-display text-3xl font-semibold md:text-4xl">Administrator login</h1>
            <p className="mt-4 max-w-2xl text-sm text-[var(--muted)]">Secure sign in for site administrators. This demo page is a styled placeholder — integrate your auth provider for real access.</p>
          </Reveal>

          <div className="mt-10 grid gap-8 md:grid-cols-2">
            <div className="card-surface rounded-2xl p-6">
              <h3 className="font-display text-lg font-semibold">Quick site stats</h3>
              <p className="mt-2 text-sm text-[var(--muted)]">Overview, pending requests, and recent installs are available here once the dashboard is connected.</p>
              <ul className="mt-4 space-y-2">
                <li className="text-sm">• Pending requests: <strong>12</strong></li>
                <li className="text-sm">• Active bids: <strong>3</strong></li>
                <li className="text-sm">• Systems installed this month: <strong>27</strong></li>
              </ul>
            </div>

            <div className="card-surface rounded-2xl p-6">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="mb-2 block text-sm text-[var(--muted)]">Email</label>
                  <div className="relative">
                    <input name="email" value={form.email} onChange={handleChange} className="w-full rounded-xl border px-4 py-3 text-sm text-[var(--text)] placeholder:text-[var(--muted)]/70 bg-[var(--bg)]" placeholder="admin@company.com" />
                    <Mail size={16} className="absolute right-3 top-3 text-[var(--muted)]" />
                  </div>
                </div>

                <div>
                  <label className="mb-2 block text-sm text-[var(--muted)]">Password</label>
                  <div className="relative">
                    <input name="password" value={form.password} onChange={handleChange} type="password" className="w-full rounded-xl border px-4 py-3 text-sm text-[var(--text)] placeholder:text-[var(--muted)]/70 bg-[var(--bg)]" placeholder="••••••••" />
                    <Lock size={16} className="absolute right-3 top-3 text-[var(--muted)]" />
                  </div>
                </div>

                {error && <p className="text-xs text-red-400">{error}</p>}

                <motion.button whileTap={{ scale: 0.98 }} type="submit" disabled={isSubmitting} className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-dawn-gradient px-6 py-3.5 font-medium text-[var(--bg)] shadow-glow">
                  {isSubmitting ? "Signing in…" : "Sign in"}
                </motion.button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
