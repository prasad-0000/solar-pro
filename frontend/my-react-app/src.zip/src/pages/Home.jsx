import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import { motion } from "framer-motion";
import {
  ArrowRight,
  BatteryCharging,
  BookOpen,
  Building2,
  Calculator,
  ChevronDown,
  Leaf,
  Lightbulb,
  PiggyBank,
  ShieldCheck,
  Sun,
  Zap,
} from "lucide-react";
import Reveal, { RevealStagger, staggerItem } from "../components/Reveal.jsx";
import SunArc from "../components/SunArc.jsx";
import StatCounter from "../components/StatCounter.jsx";

const highlights = [
  { icon: Zap, title: "Live in ~6 weeks", body: "Design, permits, and install handled end to end by one crew." },
  { icon: PiggyBank, title: "0% financing", body: "Own your system for less than most people pay for grid power." },
  { icon: ShieldCheck, title: "25-year warranty", body: "Panels, inverter, and labor — all covered, all in writing." },
];

const steps = [
  { n: "01", title: "Free site assessment", body: "We map your roof, shading, and usage to size a system that fits." },
  { n: "02", title: "Custom design + permits", body: "Engineering drawings and utility paperwork, filed for you." },
  { n: "03", title: "Install in 1–2 days", body: "Certified crews, minimal disruption, full site cleanup." },
  { n: "04", title: "Flip the switch", body: "Monitor production from your phone from day one." },
];

const faqItems = [
  { q: "How long does a solar installation take?", a: "Most residential systems take about 4 to 8 weeks from signed contract to final utility approval, with installation itself usually completed in 1 to 2 days." },
  { q: "Will solar still work during storms or outages?", a: "Yes. Panels continue producing when conditions are safe, and paired battery storage keeps essential loads running during grid outages." },
  { q: "Do you handle permits and utility paperwork?", a: "Absolutely. Our team manages design, permits, interconnection, inspection coordination, and final activation for you." },
  { q: "What if my roof isn’t ideal for solar?", a: "We review roof orientation, shading, age, and usage before recommending the best possible system design or alternative solutions." },
];

const resources = [
  {
    icon: BookOpen,
    title: "Solar buying guide",
    body: "A practical breakdown of system sizing, panel choices, and what really matters during design.",
  },
  {
    icon: Calculator,
    title: "ROI checklist",
    body: "Compare utility offset, financing, and maintenance planning before committing to a project.",
  },
  {
    icon: Lightbulb,
    title: "Battery planning",
    body: "Learn how backup power improves resilience and supports smarter energy use during peak rates.",
  },
  {
    icon: ShieldCheck,
    title: "Maintenance essentials",
    body: "Simple best practices for protecting performance, warranties, and long-term production.",
  },
];

export default function Home() {
  const [openFaq, setOpenFaq] = useState(0);
  const panelTypes = [
    {
      key: "monocrystalline",
      title: "Monocrystalline",
      desc: "High-efficiency single-crystal cells, great for limited roof space.",
    },
    {
      key: "polycrystalline",
      title: "Polycrystalline",
      desc: "More affordable multi-crystal cells with slightly lower efficiency.",
    },
    {
      key: "thinfilm",
      title: "Thin-Film",
      desc: "Lightweight, flexible panels used for specialty installations and some commercial roofs.",
    },
  ];

  const panelLayers = [
    { name: "Tempered glass", note: "Protects front surface" },
    { name: "EVA encapsulant", note: "Bonds cells to glass" },
    { name: "Solar cells", note: "The active photovoltaic layer(s)" },
    { name: "Backsheet", note: "Protects rear of the module" },
    { name: "Aluminum frame", note: "Structural support and mounting" },
  ];

  const brands = ["SunPower", "LG", "Q CELLS", "REC", "Panasonic"];
  const testimonials = [
    { quote: "Switching to Solstice cut our bills in half — professional crew and great communication.", name: "Alex Perez", location: "Austin, TX" },
    { quote: "They handled permits, install, and the utility paperwork with no stress. Highly recommend.", name: "Maya Thompson", location: "San Antonio, TX" },
    { quote: "Beautiful install and the monitoring app makes it easy to track production every day.", name: "Samir K.", location: "Dallas, TX" },
  ];

  return (
    <div>
      <section className="relative overflow-hidden">
        <div className="solar-grid absolute inset-0 opacity-50" />
        <div className="absolute inset-0 bg-horizon-fade" />
        <div className="absolute -top-24 right-[-15%] h-80 w-80 rounded-full bg-[rgba(255,122,69,0.12)] blur-[90px]" />
        <div className="absolute left-[-8%] top-1/3 h-72 w-72 rounded-full bg-[rgba(79,209,197,0.12)] blur-[90px]" />

        <div className="relative mx-auto max-w-7xl px-5 pb-10 pt-16 md:px-8 md:pb-16 md:pt-24">
          <div className="grid items-center gap-10 md:grid-cols-2">
            <div>
              <motion.span
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="eyebrow"
              >
                <Sun size={12} /> Residential &amp; commercial solar
              </motion.span>

              <motion.h1
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="mt-5 max-w-xl font-display text-4xl font-semibold leading-[1.05] tracking-tight sm:text-5xl lg:text-6xl"
              >
                Bright ideas.
                <br />
                <span className="text-gradient">Smarter power.</span>
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="mt-6 max-w-lg text-lg leading-relaxed text-[var(--muted)]"
              >
                Solstice designs, permits, and installs premium solar systems that reduce bills,
                strengthen energy independence, and look beautiful on every roofline.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="mt-8 flex flex-wrap items-center gap-4"
              >
                <NavLink to="/contact" className="btn-primary group">
                  Get your free quote
                  <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
                </NavLink>
                <NavLink to="/projects" className="btn-secondary">
                  See recent installs
                </NavLink>
              </motion.div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.5 }}
                className="mt-8 flex flex-wrap items-center gap-6"
              >
                <div className="flex items-center -space-x-2">
                  {['SL', 'AR', 'MK'].map((label) => (
                    <span key={label} className="flex h-10 w-10 items-center justify-center rounded-full border border-[var(--border)] bg-[var(--card)] text-[10px] font-semibold tracking-[0.12em] text-[var(--muted-strong)]">
                      {label}
                    </span>
                  ))}
                </div>
                <div>
                  <div className="font-display text-lg font-semibold text-[var(--text)]">4,200+ projects</div>
                  <div className="text-sm text-[var(--muted)]">Trusted by homeowners and business owners</div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 }}
                className="mt-8 grid max-w-xl gap-3 sm:grid-cols-3"
              >
                {[
                  { label: "Residential", to: "/residential", description: "Home solar" },
                  { label: "Commercial", to: "/commercial", description: "Business power" },
                  { label: "Storage", to: "/storage", description: "Backup + control" },
                ].map((item) => (
                  <NavLink
                    key={item.label}
                    to={item.to}
                    className="group rounded-2xl border border-[var(--border)] bg-[var(--panel)] p-3.5 transition-all duration-200 hover:-translate-y-0.5 hover:border-[rgba(255,183,77,0.3)] hover:bg-[rgba(255,183,77,0.04)]"
                  >
                    <div className="text-[10px] font-semibold uppercase tracking-[0.14em] text-[var(--primary)]">{item.label}</div>
                    <div className="mt-2 text-sm text-[var(--muted)]">{item.description}</div>
                  </NavLink>
                ))}
              </motion.div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.7 }}
                className="mt-10 grid max-w-md grid-cols-3 gap-3"
              >
                <StatCounter value={4200} suffix="+" label="Systems installed" />
                <StatCounter value={98} suffix="%" label="On-time rate" />
                <StatCounter value={25} suffix="yr" label="Warranty" />
              </motion.div>
            </div>

            <motion.div
              initial={{ opacity: 0, scale: 0.98, y: 24 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.15 }}
              className="relative"
            >
              <div className="hero-card overflow-hidden p-4 md:p-5">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_rgba(255,183,77,0.18),_transparent_42%)]" />
                <div className="relative">
                  <div className="flex items-center justify-between gap-4 px-2">
                    <span className="floating-badge">
                      <Leaf size={12} className="text-[var(--secondary)]" /> Live performance
                    </span>
                    <span className="rounded-full border border-[var(--border)] bg-[rgba(255,255,255,0.03)] px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.15em] text-[var(--muted)]">
                      +24.6% YoY
                    </span>
                  </div>

                  <div className="mt-4 rounded-[1.75rem] border border-[var(--border)] bg-[rgba(255,255,255,0.02)] p-3 md:p-4">
                    <SunArc />
                  </div>

                  <div className="mt-5 grid gap-4 sm:grid-cols-2">
                    <div className="card-surface rounded-2xl p-4">
                      <div className="text-[11px] uppercase tracking-[0.14em] text-[var(--muted)]">Energy today</div>
                      <div className="mt-2 font-display text-3xl font-semibold text-[var(--text)]">68 kWh</div>
                      <div className="mt-2 text-sm text-[var(--muted)]">Up 17% vs. last week</div>
                    </div>
                    <div className="card-surface rounded-2xl p-4">
                      <div className="text-[11px] uppercase tracking-[0.14em] text-[var(--muted)]">Savings</div>
                      <div className="mt-2 font-display text-3xl font-semibold text-[var(--text)]">$214</div>
                      <div className="mt-2 text-sm text-[var(--muted)]">Projected monthly offset</div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <div className="section-divider" />

      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <Reveal>
            <span className="eyebrow">Customer stories</span>
            <h2 className="mt-3 max-w-xl font-display text-3xl font-semibold md:text-4xl">Real homeowners, real results.</h2>
          </Reveal>

          <RevealStagger className="mt-12 grid gap-6 sm:grid-cols-1 md:grid-cols-3">
            {testimonials.map((t) => (
              <motion.div key={t.name} variants={staggerItem} whileHover={{ y: -6 }} className="card-surface rounded-2xl p-6">
                <p className="text-sm leading-relaxed text-[var(--muted)]">“{t.quote}”</p>
                <div className="mt-4 flex items-center gap-3">
                  <div className="h-10 w-10 flex-shrink-0 rounded-full bg-[rgba(255,255,255,0.02)] border border-[var(--border)] flex items-center justify-center font-semibold text-[var(--text)]">{t.name.split(" ")[0].charAt(0)}</div>
                  <div>
                    <div className="font-display text-sm font-semibold text-[var(--text)]">{t.name}</div>
                    <div className="text-xs text-[var(--muted)]">{t.location}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </RevealStagger>
        </div>
      </section>

      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <Reveal>
            <span className="eyebrow">Solar panel types</span>
            <h2 className="mt-3 max-w-xl font-display text-3xl font-semibold md:text-4xl">
              Types, typical layers, and brands we work with.
            </h2>
          </Reveal>

          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {panelTypes.map((p) => (
              <motion.div key={p.key} variants={staggerItem} whileHover={{ y: -6 }} className="card-surface rounded-2xl p-6 text-center">
                <div className="mb-4 h-40 w-full overflow-hidden rounded-xl bg-gradient-to-br from-[rgba(79,209,197,0.06)] to-[rgba(255,183,77,0.04)]">
                  <div className="flex h-full items-center justify-center text-sm text-[var(--muted)]">Image placeholder for {p.title}</div>
                </div>
                <h3 className="font-display text-lg font-semibold text-[var(--text)]">{p.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-[var(--muted)]">{p.desc}</p>
              </motion.div>
            ))}
          </div>

          <div className="mt-10">
            <h3 className="font-display text-xl font-semibold">Common panel layers</h3>
            <p className="mt-2 text-sm text-[var(--muted)]">Modern crystalline modules commonly include the following stacked layers.</p>
            <ul className="mt-4 grid gap-3 sm:grid-cols-2 md:grid-cols-3">
              {panelLayers.map((l) => (
                <li key={l.name} className="card-surface rounded-2xl p-4">
                  <div className="font-display text-sm font-semibold text-[var(--text)]">{l.name}</div>
                  <div className="mt-1 text-sm text-[var(--muted)]">{l.note}</div>
                </li>
              ))}
            </ul>
          </div>

          <div className="mt-8">
            <h3 className="font-display text-xl font-semibold">Brands we often install</h3>
            <div className="mt-3">
              <div className="flex overflow-x-auto flex-nowrap gap-3 py-2">
                {brands.map((b) => (
                  <span key={b} className="min-w-max rounded-md border border-[var(--border)] bg-[var(--panel)] px-3 py-1 text-sm font-semibold">{b}</span>
                ))}
              </div>
            </div>
            <p className="mt-3 text-sm text-[var(--muted)]">Want your brand listed? We can source or install a wide range of OEM modules — tell us which you prefer.</p>
          </div>
        </div>
      </section>

      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <Reveal>
            <span className="eyebrow">Why Solstice</span>
            <h2 className="mt-3 max-w-xl font-display text-3xl font-semibold md:text-4xl">
              Solar, without the runaround.
            </h2>
          </Reveal>

          <RevealStagger className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {highlights.map((h) => (
              <motion.div
                key={h.title}
                variants={staggerItem}
                whileHover={{ y: -6 }}
                className="card-surface rounded-2xl p-7 transition-all duration-300 hover:border-[rgba(255,183,77,0.35)]"
              >
                <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-xl border border-[rgba(255,183,77,0.25)] bg-[rgba(255,183,77,0.08)]">
                  <h.icon size={20} className="text-[var(--primary)]" />
                </div>
                <h3 className="font-display text-xl font-semibold text-[var(--text)]">{h.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-[var(--muted)]">{h.body}</p>
              </motion.div>
            ))}
          </RevealStagger>
        </div>
      </section>

      <div className="section-divider" />

      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <Reveal>
            <span className="eyebrow">Resources</span>
            <h2 className="mt-3 max-w-xl font-display text-3xl font-semibold md:text-4xl">
              Clear guidance for smarter solar decisions.
            </h2>
          </Reveal>

          <RevealStagger className="mt-12 grid gap-6 md:grid-cols-2 xl:grid-cols-4">
            {resources.map((resource) => (
              <motion.div
                key={resource.title}
                variants={staggerItem}
                whileHover={{ y: -6 }}
                className="card-surface rounded-2xl p-7 transition-all duration-300 hover:border-[rgba(255,183,77,0.35)]"
              >
                <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-xl border border-[rgba(255,183,77,0.25)] bg-[rgba(255,183,77,0.08)]">
                  <resource.icon size={20} className="text-[var(--primary)]" />
                </div>
                <h3 className="font-display text-xl font-semibold text-[var(--text)]">{resource.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-[var(--muted)]">{resource.body}</p>
              </motion.div>
            ))}
          </RevealStagger>

          <div className="mt-8 text-center">
            <NavLink to="/resources" className="btn-secondary">
              Explore all resources
            </NavLink>
          </div>
        </div>
      </section>

      <div className="section-divider" />

      <section className="bg-[var(--panel)] py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <Reveal>
            <span className="eyebrow">The process</span>
            <h2 className="mt-3 max-w-xl font-display text-3xl font-semibold md:text-4xl">
              From roof scan to power-on in four steps.
            </h2>
          </Reveal>

          <div className="relative mt-14 grid gap-8 md:grid-cols-4">
            <div className="absolute left-0 right-0 top-6 hidden h-px bg-gradient-to-r from-transparent via-[rgba(255,183,77,0.25)] to-transparent md:block" />
            {steps.map((s, i) => (
              <Reveal key={s.n} delay={i * 0.1}>
                <div className="mb-4 font-mono text-sm font-semibold text-[var(--primary)]">{s.n}</div>
                <h3 className="font-display text-lg font-semibold text-[var(--text)]">{s.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-[var(--muted)]">{s.body}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <Reveal>
            <span className="eyebrow">Frequently asked</span>
            <h2 className="mt-3 max-w-xl font-display text-3xl font-semibold md:text-4xl">
              Helpful answers before your first call.
            </h2>
          </Reveal>

          <div className="mt-12 space-y-4">
            {faqItems.map((item, index) => (
              <motion.div key={item.q} initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.2 }} transition={{ duration: 0.45, delay: index * 0.06 }} className="card-surface overflow-hidden rounded-2xl">
                <button
                  type="button"
                  onClick={() => setOpenFaq((current) => (current === index ? -1 : index))}
                  className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left md:px-6"
                  aria-expanded={openFaq === index}
                >
                  <span className="font-display text-lg font-semibold text-[var(--text)]">{item.q}</span>
                  <ChevronDown size={18} className={`shrink-0 text-[var(--primary)] transition-transform duration-200 ${openFaq === index ? "rotate-180" : ""}`} />
                </button>
                <motion.div
                  initial={false}
                  animate={{ height: openFaq === index ? "auto" : 0, opacity: openFaq === index ? 1 : 0 }}
                  transition={{ duration: 0.2, ease: "easeOut" }}
                  className="overflow-hidden"
                >
                  <p className="px-5 pb-5 text-sm leading-relaxed text-[var(--muted)] md:px-6">{item.a}</p>
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="pb-20 md:pb-28">
        <div className="mx-auto max-w-5xl px-5 md:px-8">
          <Reveal>
            <div className="relative overflow-hidden rounded-[2rem] bg-dawn-gradient p-8 text-[var(--bg)] md:p-12">
              <div className="absolute -bottom-14 -right-10 h-44 w-44 rounded-full bg-[rgba(255,255,255,0.15)] blur-2xl" />
              <div className="relative flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
                <div>
                  <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-[rgba(10,18,26,0.15)] bg-[rgba(10,18,26,0.06)] px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-[rgba(10,18,26,0.75)]">
                    <BatteryCharging size={12} /> Clean energy, smarter living
                  </div>
                  <h3 className="max-w-md font-display text-2xl font-semibold md:text-3xl">
                    See what your roof could be earning.
                  </h3>
                  <p className="mt-2 max-w-md text-sm text-[rgba(10,18,26,0.75)]">
                    Free, no-obligation recommendations from a team that designs premium systems for real homes and businesses.
                  </p>
                </div>
                <NavLink to="/contact" className="btn-secondary border-[rgba(10,18,26,0.14)] bg-[rgba(10,18,26,0.04)] text-[var(--bg)] hover:bg-[rgba(10,18,26,0.08)]">
                  Get your free quote
                  <ArrowRight size={16} />
                </NavLink>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
