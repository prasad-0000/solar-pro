import React, { useState } from "react";
import { motion, AnimatePresence, LayoutGroup } from "framer-motion";
import { MapPin, Zap } from "lucide-react";
import Reveal from "../components/Reveal.jsx";

const filters = ["All", "Residential", "Commercial", "Battery"];

const projects = [
  { title: "Hillcrest Residence", type: "Residential", loc: "Austin, TX", size: "9.2 kW", hue: "from-[var(--primary-strong)] to-[var(--primary)]" },
  { title: "Meridian Logistics Roof", type: "Commercial", loc: "Round Rock, TX", size: "410 kW", hue: "from-[var(--secondary)] to-[var(--primary-strong)]" },
  { title: "Oakview Backup System", type: "Battery", loc: "Cedar Park, TX", size: "20 kWh", hue: "from-[var(--primary)] to-[var(--secondary)]" },
  { title: "Sunridge Family Home", type: "Residential", loc: "San Marcos, TX", size: "7.8 kW", hue: "from-[var(--primary-strong)] to-[var(--secondary)]" },
  { title: "Bell Foundry Warehouse", type: "Commercial", loc: "Georgetown, TX", size: "620 kW", hue: "from-[var(--primary)] to-[var(--primary-strong)]" },
  { title: "Lakeside Storage Retrofit", type: "Battery", loc: "Austin, TX", size: "10 kWh", hue: "from-[var(--secondary)] to-[var(--primary)]" },
];

export default function Projects() {
  const [filter, setFilter] = useState("All");
  const visible = filter === "All" ? projects : projects.filter((p) => p.type === filter);

  return (
    <div>
      <section className="bg-horizon-fade pb-12 pt-16 md:pt-24">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <Reveal>
            <span className="eyebrow">Projects</span>
            <h1 className="mt-3 max-w-2xl font-display text-4xl font-semibold leading-tight md:text-5xl">
              A few roofs we’re proud of.
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-[var(--muted)]">
              A sample of recent residential, commercial, and battery installs across Central Texas.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="py-16 md:py-20">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <LayoutGroup>
            <div className="mb-10 flex flex-wrap gap-2">
              {filters.map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`relative rounded-full px-5 py-2.5 text-sm font-medium transition-colors ${
                    filter === f ? "text-[var(--bg)]" : "text-[var(--muted)] hover:text-[var(--text)]"
                  }`}
                >
                  {filter === f && (
                    <motion.span
                      layoutId="projectFilterBg"
                      className="absolute inset-0 rounded-full bg-dawn-gradient"
                      transition={{ type: "spring", stiffness: 400, damping: 32 }}
                    />
                  )}
                  <span className="relative z-10">{f}</span>
                </button>
              ))}
            </div>

            <motion.div layout className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              <AnimatePresence mode="popLayout">
                {visible.map((p) => (
                  <motion.div
                    key={p.title}
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                    whileHover={{ y: -6 }}
                    className="overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--panel)] transition-colors hover:border-[rgba(255,183,77,0.3)]"
                  >
                    <div className={`relative h-40 bg-gradient-to-br ${p.hue} opacity-90`}>
                      <div className="absolute inset-0 bg-[rgba(7,19,29,0.16)]" />
                      <span className="absolute right-3 top-3 rounded-full bg-[rgba(7,19,29,0.55)] px-2.5 py-1 text-[11px] font-mono uppercase tracking-[0.14em] text-[var(--text)] backdrop-blur-sm">
                        {p.type}
                      </span>
                    </div>
                    <div className="p-6">
                      <h3 className="font-display text-lg font-semibold text-[var(--text)]">{p.title}</h3>
                      <div className="mt-3 flex items-center gap-4 text-sm text-[var(--muted)]">
                        <span className="flex items-center gap-1.5">
                          <MapPin size={13} className="text-[var(--primary)]" /> {p.loc}
                        </span>
                        <span className="flex items-center gap-1.5">
                          <Zap size={13} className="text-[var(--secondary)]" /> {p.size}
                        </span>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </motion.div>
          </LayoutGroup>
        </div>
      </section>
    </div>
  );
}

